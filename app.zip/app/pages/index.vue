<template>
  <div class="h-full flex flex-col gap-4">
    <AppHero class="mb-1" />
    <div class="flex-1 flex flex-col px-3 mt-3">
      <AppBookmarks />
    </div>
  </div>
</template>
