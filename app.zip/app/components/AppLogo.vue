<template>
  <div class="h-full flex items-center">
    <img
      src="/img/logo.png"
      class="h-10"
    >
  </div>
</template>
