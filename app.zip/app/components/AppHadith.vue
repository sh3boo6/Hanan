<script setup lang="ts">
interface HadithResponse {
  hadith?: {
    text: string
    hadithnumber: number | string
  }
  section?: {
    bookname?: string
  }
}

const currentHadith = ref({
  text: 'جاري تحميل الحديث الشريف...',
  source: 'البخاري أو مسلم'
})
const isLoadingHadith = ref(false)

const fetchRandomHadith = async () => {
  isLoadingHadith.value = true
  try {
    const books = ['bukhari', 'muslim']
    const randomBook = books[Math.floor(Math.random() * books.length)]

    const maxHadith = randomBook === 'bukhari' ? 7000 : 3000
    const randomId = Math.floor(Math.random() * maxHadith) + 1

    const response = await $fetch<HadithResponse>(`https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/ara-${randomBook}/${randomId}.json`)

    if (response && response.hadith) {
      currentHadith.value = {
        text: response.hadith.text,
        source: `${response.section?.bookname || randomBook} (رقم الحديث: ${response.hadith.hadithnumber})`
      }
    }
  } catch {
    currentHadith.value = {
      text: 'إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.',
      source: 'صحيح البخاري'
    }
  } finally {
    isLoadingHadith.value = false
  }
}

const fetchDailyHadith = () => {
  const today = new Date().toISOString().slice(0, 10)
  const savedDate = localStorage.getItem('daily_hadith_date')
  const savedHadith = localStorage.getItem('daily_hadith_data')

  if (savedDate === today && savedHadith) {
    try {
      currentHadith.value = JSON.parse(savedHadith)
    } catch {
      fetchRandomHadith()
    }
  } else {
    fetchRandomHadith().then(() => {
      localStorage.setItem('daily_hadith_date', today)
      localStorage.setItem('daily_hadith_data', JSON.stringify(currentHadith.value))
    })
  }
}

onMounted(() => {
  fetchDailyHadith()
})
</script>

<template>
  <div class="bg-linear-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-2xl p-4 flex flex-col gap-2 shadow-sm w-full">
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-2 text-primary font-semibold text-sm">
        <UIcon
          name="i-lucide-book-open"
          class="w-4 h-4"
        />
        <span>الحديث الشريف</span>
      </div>
      <UButton
        size="xs"
        color="primary"
        variant="ghost"
        icon="i-lucide-rotate-cw"
        :loading="isLoadingHadith"
        label="حديث آخر"
        @click="fetchRandomHadith"
      />
    </div>
    <p class="text-sm text-foreground/90 font-medium leading-relaxed">
      "{{ currentHadith.text }}"
    </p>
    <span class="text-[11px] text-muted self-end">
      [ {{ currentHadith.source }} ]
    </span>
  </div>
</template>
