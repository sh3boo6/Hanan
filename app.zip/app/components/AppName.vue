<template>
  <div class="inline mx-1">
    App Name
  </div>
</template>
