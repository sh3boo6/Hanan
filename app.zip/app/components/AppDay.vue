<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'

interface Props {
  locale?: string
  hijriLocale?: string
}

const props = withDefaults(defineProps<Props>(), {
  locale: 'en-GB',
  hijriLocale: 'ar-SA-u-ca-islamic-umalqura'
})

const dayName = ref('')
const hijriDate = ref('')
const gregorianDate = ref('')

let timer: NodeJS.Timeout | null = null

function updateDates() {
  const now = new Date()

  dayName.value = new Intl.DateTimeFormat(props.hijriLocale, { weekday: 'long' }).format(now)
  hijriDate.value = new Intl.DateTimeFormat(props.hijriLocale, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(now)

  gregorianDate.value = new Intl.DateTimeFormat(props.locale, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(now)
}

onMounted(() => {
  updateDates()
  timer = setInterval(updateDates, 60000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
</script>

<template>
  <div class="flex flex-col gap-1 text-right border-s-4 border-s-primary/70 ps-4">
    <div class="text-3xl font-semibold">
      {{ dayName }}
    </div>
    <p class="text-xl font-semibold">
      {{ hijriDate }}
    </p>
    <p
      dir="ltr"
      class="text-lg font-semibold"
    >
      {{ gregorianDate }}
    </p>
  </div>
</template>
